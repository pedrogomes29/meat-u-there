#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    if(argc != 3){
        printf("usage: addmx file1 file2\n");
        return -1;
    }

    /* ------ create and read matrixes ------ */
    char* infile_matrix_1 = argv[1];
    FILE *fp1;
    if((fp1 = fopen(infile_matrix_1,"r")) == NULL){
        perror("cannot open file");
        exit(EXIT_FAILURE);
    }
    size_t str_size = 0;
    char* str = NULL;
    getline(&str, &str_size, fp1);

    char* tok= strtok(str,"x");
    int num_lines = atoi(tok);
    tok= strtok(NULL,"x");
    int num_cols = atoi(tok);

    int matrix_1[num_lines][num_cols];

    int i = 0, j = 0;

    while ( getline(&str, &str_size, fp1) > 0 ) {
        char* token = strtok(str," ");
        while( token != NULL ) {
            matrix_1[i][j]=atoi(token);
            token=strtok(NULL," ");
            j++;
        }
        i++;
        j=0;
    }
    fclose(fp1);

    
    char* infile_matrix_2 = argv[2];
    FILE *fp2;
    if((fp2 = fopen(infile_matrix_2,"r")) == NULL){
        perror("cannot open file");
        exit(EXIT_FAILURE);
    }
    str_size = 0;
    str = NULL;
    getline(&str, &str_size, fp2);

    tok= strtok(str,"x");
    int num_lines_2 = atoi(tok);
    tok= strtok(NULL,"x");
    int num_cols_2 = atoi(tok);


    if(num_lines!=num_lines_2 || num_cols!=num_cols_2)
        return EXIT_FAILURE;

    int matrix_2[num_lines][num_cols];

    i = 0;
    j = 0;

    while ( getline(&str, &str_size, fp2) > 0 ) {
        char* token = strtok(str," ");
        while( token != NULL ) {
            matrix_2[i][j]=atoi(token);
            token=strtok(NULL," ");
            j++;
        }
        i++;
        j=0;
    }
    fclose(fp2);

   

    /* ------ setup shared memory ------ */
    int *answer = mmap(NULL, num_cols*num_lines*sizeof(int), PROT_READ|PROT_WRITE,
    MAP_SHARED|MAP_ANONYMOUS, 0, 0);
    if(answer == MAP_FAILED){
        perror("mmap");
        exit(EXIT_FAILURE);
    }
    memset(answer,0,num_cols*num_lines*sizeof(int));

    /* ------ start n_col procs and do work ------ */
    for(j = 0; j < num_cols; j++) {
        pid_t pid;
        if ((pid = fork()) < 0) {
            perror("fork");
            exit(EXIT_FAILURE);
        }
        if(pid == 0) {
            for(int i=0;i<num_lines;i++){
                answer[i*num_lines+j]=matrix_1[i][j]+matrix_2[i][j];
            }
            exit(EXIT_SUCCESS);
        }
    }
    
    for(i = 0; i < num_cols; i++) {
        if ( waitpid(-1, NULL, 0) < 0) {
            perror("waitpid");
            exit(EXIT_FAILURE);
        }
    }
    /* ler resultados enviados pelos processos filhos */
    printf("%dx%d\n",num_lines,num_cols);
    for(i = 0; i < num_lines; i++){
        for(j = 0; j < num_cols; j++){
            printf("%d ",answer[i*num_lines+j]);
        }
        printf("\n");
    }

    /* ------ release shared memory ------ */
    if (munmap(answer, sizeof(answer)) < 0) {
        perror("munmap");
        exit(EXIT_FAILURE);
    }
    exit(EXIT_SUCCESS);
}