#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdbool.h>

#define BUFFER_SIZE 10000

char* trim(char *str){
    
    while (*str == ' '  && *str != 0 )
    {
        str++;
    }
    return str;
}

int main (int argc, char *argv[]) {
    if(argc != 2 && argc!=3) {
        printf("usage: phrases [-l] file\n");
        return 1;
    }

    char *filename;

    if(argc == 3){
        char flag [] = "-l";
        if(strcmp(flag,argv[1])){
            printf("usage: phrases [-l] file\n");
            return 1;
        }
        
        filename = argv[2];
    }else{
        filename = argv[1];
    }
    
    FILE *fp = fopen(filename, "r");
    char phrase [BUFFER_SIZE];
    if (fp == NULL)
    {
        printf("Error: could not open file %s \n", filename);
        return 1;
    }
    
    int count = 0;
    char pontos [BUFFER_SIZE];
    bool middle_line = false;
    
    int ct=0;
    int line_len = 0;
    while (fgets(&phrase[ct], BUFFER_SIZE, fp) != 0){
        phrase[strcspn(phrase, "\r\n")] = 0;    // limpar \n se existir
        int pt=0;
        
        while(phrase[ct]){  // guardar pontos
            char ch = phrase[ct];
            ct++;
            if(ch=='!' || ch=='?' || ch=='.'){
                pontos[pt] = ch;
                pt++;
                middle_line = false;
            }else{
                middle_line = true;
            }
        }

        char *token = strtok(phrase, ".!?");
        
        int line = 0 ;

        while(token!=NULL && line < pt){
            if(argc==3)    
                printf("[%d] %s%c\n", count+1, trim(token), pontos[line]);
            count++;
            line++;
            token = strtok(NULL, ".!?");
        }
        
        ct = 0;
        if(middle_line && token!=NULL){
            strcpy(phrase, token);
            ct = strlen(phrase);
        }
    }
    
    if(argc == 3 && ct)
        printf("[%d] %s\n", count+1, trim(phrase));

    if(argc == 2)
        printf("%d\n",count+1);
    
    return 0;
}