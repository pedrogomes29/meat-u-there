#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>

#define READ_END 0
#define WRITE_END 1
#define BUFFERS_SIZE 1024
#define WORD_SIZE 256

void send_input2pipe(char *buffer, size_t size, int pipe_descriptor){
    int nBytes;
    while ((nBytes=read(STDIN_FILENO, buffer, size)) != 0)
    {
        buffer[nBytes] = 0;
    
        if (write(pipe_descriptor, buffer, nBytes) != nBytes)
        {
            fprintf(stderr, "Failed to write to pipe\n");
            exit(1);
        }
    }
}

char*** create_cypher_array(char * file_name, int *size){
    FILE * file = fopen(file_name, "r");
    
    if(file == NULL){
        printf("Cant open file %s", file_name);
        exit(EXIT_FAILURE);
    }

    char word1[WORD_SIZE];
    char word2[WORD_SIZE];

    size_t nLines = 0;
    char *** array = NULL; // string[nLINES][2]
    while(fscanf(file, "%s %s", word1, word2) != -1){

        if(strcmp(word1 ,"") == 0 || strcmp(word2 ,"") == 0)
            break;
        if(nLines>5)
            break;

        ++nLines;
        if(array == NULL){
            array = malloc(sizeof(char**));
        }else{
            array = realloc(array, sizeof(char**) * nLines);
        }
        
        
        array[nLines-1] = malloc(2* sizeof(char*));
        array[nLines-1][0] = strdup(word1);
        array[nLines-1][1] = strdup(word2);

    }

    fclose(file);
    *size = nLines;

    return array;
}

void cypher_text(char* word, size_t max_word_size, char*** cypher_array, int size){

    for(int i = 0; i < size ; i++){
        if(strncmp(word, cypher_array[i][0], max_word_size) == 0){
            
            strncpy(word,  cypher_array[i][1], max_word_size);
            break;
        }

        if(strncmp(word, cypher_array[i][1], max_word_size) == 0){
            
            strncpy(word,  cypher_array[i][0], max_word_size);
            break;
        }
    }


}



int main(int argc, char* argv[]) {
    
    
    int pipe_parent_child[2];
    int pipe_child_parent[2];

    if (pipe(pipe_parent_child) < 0) {
        perror("pipe parent_child error");
        exit(EXIT_FAILURE);
    }

    if (pipe(pipe_child_parent) < 0) {
        perror("pipe child_parent error");
        exit(EXIT_FAILURE);
    }
    int pid = fork();

    if(pid < 0){
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if(pid > 0){
        /* Parent */
        close(pipe_parent_child[READ_END]);     // close read
        close(pipe_child_parent[WRITE_END]);    // close write 

        char buffer[BUFFERS_SIZE];  

        // send input to child
        send_input2pipe(buffer, BUFFERS_SIZE, pipe_parent_child[WRITE_END]);

        close(pipe_parent_child[WRITE_END]);

        // write data from child to stout
        int nbytes;
        while ((nbytes = read(pipe_child_parent[READ_END], buffer, BUFFERS_SIZE)) > 0)
        {
            buffer[nbytes] = 0;
            fprintf(stdout, "%s", buffer);
        }

        
        close(pipe_child_parent[READ_END]);
        


    }else{
        /* Child */
        close(pipe_parent_child[WRITE_END]);     
        close(pipe_child_parent[READ_END]); 

        /* create cypher array*/
        int size = 0;
        char *** cypher_array = create_cypher_array("cypher.txt" , &size);

        char buffer[BUFFERS_SIZE];  
        int nbytes;
        

        char word[WORD_SIZE];
        int word_pos = 0;

        while ((nbytes = read(pipe_parent_child[READ_END], buffer, BUFFERS_SIZE)) > 0)
        {

            buffer[nbytes] = 0;
            
            for(int i = 0 ; i < nbytes; i++){
                if(isalpha(buffer[i])){
                    if(word_pos == WORD_SIZE-1)
                        continue;
                        
                    word[word_pos++] = buffer[i];
                }else{
                    if(word_pos != 0){
                        word[word_pos] = 0;
                        // check if cypher exist for this word
                        
                        //fprintf(stderr, "Word '%s' ", word);
                        cypher_text(word, WORD_SIZE, cypher_array, size);
                        
                        //fprintf(stderr, "Write '%s' \n", word);
                        int len = strlen(word);
                        // send word to pipe
                        if (write(pipe_child_parent[WRITE_END], word, len) != len)
                        {
                            fprintf(stderr, "Failed to write to pipe - letter\n");
                            exit(1);
                        }
                    }
                    // send non letters to pipe
                    
                    
                     if (write(pipe_child_parent[WRITE_END], &buffer[i], 1) != 1)
                    {
                        fprintf(stderr, "Failed to write to pipe - non letter\n");
                        exit(1);
                    }
                    word_pos = 0;
                }

                
            }

        }
        
        close(pipe_child_parent[WRITE_END]);   
        close(pipe_parent_child[READ_END]); 
    }
}
